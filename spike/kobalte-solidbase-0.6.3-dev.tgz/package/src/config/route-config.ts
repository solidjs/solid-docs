export type SolidBaseRouteSelection = Record<string, string>;

export type SolidBaseRouteRule = Record<string, string | string[]>;

export type SolidBaseRouteValueConfig = {
	path?: string;
	href?: string;
	label?: string;
	lang?: string;
} & Record<string, unknown>;

export type SolidBaseRouteAxisConfig = {
	default: string;
	values: Record<string, SolidBaseRouteValueConfig>;
};

export type SolidBaseRoutesConfig = {
	path: `/${string}`;
	include?: SolidBaseRouteRule[];
	[key: string]:
		| `/${string}`
		| SolidBaseRouteRule[]
		| SolidBaseRouteAxisConfig
		| undefined;
};

export type SolidBaseRouteOption = {
	name: string;
	axis: string;
	path?: string;
	href?: string;
	isExternal: boolean;
	selection?: SolidBaseRouteSelection;
	meta: SolidBaseRouteValueConfig;
};

export type SolidBaseRoutePathMatch = {
	selection: SolidBaseRouteSelection;
	restPath: `/${string}`;
};

export type SolidBaseRouteValueOverrideConfig = {
	label?: string;
	title?: string;
	status?: string;
} & Record<string, unknown>;

export type SolidBaseRouteValueOverride = Record<
	string,
	Record<string, SolidBaseRouteValueOverrideConfig>
>;

type RouteConfigValue = Record<string, unknown>;

type RouteTemplateSegment =
	| { type: "static"; value: string }
	| { type: "axis"; name: string };

const ROUTES_RESERVED_KEYS = new Set(["path", "include"]);
const ROUTE_OVERRIDE_KEY = "route";
const ROUTE_OVERRIDE_RESERVED_KEYS = new Set(["path", "href", "lang"]);

function isRecord(value: unknown): value is Record<string, unknown> {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function isSolidBaseRouteAxisConfig(
	value: unknown,
): value is SolidBaseRouteAxisConfig {
	return (
		isRecord(value) &&
		typeof value.default === "string" &&
		isRecord(value.values)
	);
}

export function getSolidBaseRouteAxes(
	routes: SolidBaseRoutesConfig | undefined,
) {
	if (!routes) return [];

	return Object.entries(routes).filter(
		(entry): entry is [string, SolidBaseRouteAxisConfig] =>
			isSolidBaseRouteAxisConfig(entry[1]),
	);
}

export function getSolidBaseRouteAxisNames(
	routes: SolidBaseRoutesConfig | undefined,
) {
	return getSolidBaseRouteAxes(routes).map(([name]) => name);
}

function getSolidBaseRouteAxisMap(routes: SolidBaseRoutesConfig | undefined) {
	return new Map(getSolidBaseRouteAxes(routes));
}

function assertSolidBaseRouteConfig(
	condition: unknown,
	message: string,
): asserts condition {
	if (!condition) throw new Error(`[SolidBase]: ${message}`);
}

function trimSlashes(value: string) {
	return value.replace(/^\/+|\/+$/g, "");
}

function normalizeRoutePath(path: string): `/${string}` {
	const normalized = `/${path
		.split("/")
		.map((segment) => trimSlashes(segment))
		.filter(Boolean)
		.join("/")}`;

	return normalized as `/${string}`;
}

function getRouteTemplateSegments(path: string): RouteTemplateSegment[] {
	return path
		.split("/")
		.map((segment) => trimSlashes(segment))
		.filter(Boolean)
		.map((segment) => {
			const match = segment.match(/^\{([^}]+)\}$/);
			if (match) return { type: "axis", name: match[1]! };
			return { type: "static", value: segment };
		});
}

function getRouteTemplateAxisNames(path: string) {
	return getRouteTemplateSegments(path)
		.filter((segment): segment is { type: "axis"; name: string } => {
			return segment.type === "axis";
		})
		.map((segment) => segment.name);
}

function toRuleValues(value: string | string[]) {
	return Array.isArray(value) ? value : [value];
}

function validateRouteRule(
	rule: SolidBaseRouteRule,
	axisMap: Map<string, SolidBaseRouteAxisConfig>,
	source: string,
) {
	for (const [axisName, value] of Object.entries(rule)) {
		const axis = axisMap.get(axisName);
		assertSolidBaseRouteConfig(
			axis,
			`\`${source}\` references unknown route axis \`${axisName}\`.`,
		);

		for (const valueName of toRuleValues(value)) {
			assertSolidBaseRouteConfig(
				Object.hasOwn(axis.values, valueName),
				"`" +
					source +
					"` references unknown `" +
					axisName +
					"` value `" +
					valueName +
					"`.",
			);
		}
	}
}

function getInternalRouteValueEntries(axis: SolidBaseRouteAxisConfig) {
	return Object.entries(axis.values).filter(([, value]) => !value.href);
}

function getSolidBaseRouteSelections(
	routes: SolidBaseRoutesConfig | undefined,
) {
	const axes = getSolidBaseRouteAxes(routes);
	const selections: SolidBaseRouteSelection[] = [];

	const visit = (index: number, selection: SolidBaseRouteSelection) => {
		const entry = axes[index];
		if (!entry) {
			if (isSolidBaseRouteIncluded(routes, selection)) {
				selections.push(selection);
			}
			return;
		}

		const [axisName, axis] = entry;
		for (const [valueName] of getInternalRouteValueEntries(axis)) {
			visit(index + 1, { ...selection, [axisName]: valueName });
		}
	};

	visit(0, {});
	return selections;
}

function matchRoutePathSegment(
	axis: SolidBaseRouteAxisConfig,
	pathSegment: string | undefined,
) {
	const entries = getInternalRouteValueEntries(axis);
	const defaultEntry = entries.find(
		([valueName]) => valueName === axis.default,
	);
	const explicitMatch =
		pathSegment === undefined
			? undefined
			: entries.find(([, value]) => {
					const valuePath = trimSlashes(value.path ?? "");
					return valuePath !== "" && pathSegment === valuePath;
				});

	if (explicitMatch) return explicitMatch;
	if (!defaultEntry) return undefined;

	const defaultPath = trimSlashes(defaultEntry[1].path ?? defaultEntry[0]);
	return defaultPath === "" ? defaultEntry : undefined;
}

function getRouteValuePath(
	valueName: string,
	value: SolidBaseRouteValueConfig,
) {
	return trimSlashes(value.path ?? valueName);
}

export function validateSolidBaseRoutesConfig(
	routes: SolidBaseRoutesConfig | undefined,
	overrides: RouteConfigValue[] = [],
	overrideConfigKeys: Iterable<string> = [],
) {
	if (!routes) return;

	const axisMap = getSolidBaseRouteAxisMap(routes);
	const configKeys = new Set(overrideConfigKeys);
	const placeholders = getRouteTemplateAxisNames(routes.path);

	assertSolidBaseRouteConfig(
		placeholders.length > 0,
		"`routes.path` must include at least one route axis placeholder.",
	);

	for (const key of Object.keys(routes)) {
		if (ROUTES_RESERVED_KEYS.has(key)) continue;
		assertSolidBaseRouteConfig(
			axisMap.has(key),
			`\`routes.${key}\` must include \`default\` and \`values\`.`,
		);
	}

	for (const axisName of placeholders) {
		assertSolidBaseRouteConfig(
			axisMap.has(axisName),
			`\`routes.path\` references unknown route axis \`${axisName}\`.`,
		);
	}

	for (const [axisName, axis] of axisMap) {
		assertSolidBaseRouteConfig(
			placeholders.includes(axisName),
			"`routes." +
				axisName +
				"` must be included in `routes.path` as `{" +
				axisName +
				"}`.",
		);
		assertSolidBaseRouteConfig(
			Object.hasOwn(axis.values, axis.default),
			"`routes." +
				axisName +
				".default` must reference a key in `routes." +
				axisName +
				".values`.",
		);
	}

	for (const rule of routes.include ?? []) {
		validateRouteRule(rule, axisMap, "routes.include");
	}

	for (const override of overrides) {
		const selectors: SolidBaseRouteRule = {};

		for (const [key, value] of Object.entries(override)) {
			if (axisMap.has(key)) {
				assertSolidBaseRouteConfig(
					typeof value === "string" || Array.isArray(value),
					"`overrides` selector `" +
						key +
						"` must be a string or string array.",
				);
				selectors[key] = value;
				continue;
			}

			if (key === ROUTE_OVERRIDE_KEY) {
				assertSolidBaseRouteConfig(
					isRecord(value),
					"`overrides.route` must be an object of route axis value overrides.",
				);

				for (const [axisName, values] of Object.entries(value)) {
					const axis = axisMap.get(axisName);
					assertSolidBaseRouteConfig(
						axis,
						"`overrides.route." +
							axisName +
							"` references unknown route axis `" +
							axisName +
							"`.",
					);
					assertSolidBaseRouteConfig(
						isRecord(values),
						"`overrides.route." +
							axisName +
							"` must be an object of `" +
							axisName +
							"` value overrides.",
					);

					for (const valueName of Object.keys(values)) {
						assertSolidBaseRouteConfig(
							Object.hasOwn(axis.values, valueName),
							"`overrides.route." +
								axisName +
								"` references unknown `" +
								axisName +
								"` value `" +
								valueName +
								"`.",
						);
					}

					for (const [valueName, patch] of Object.entries(values)) {
						if (!isRecord(patch)) continue;

						for (const key of Object.keys(patch)) {
							assertSolidBaseRouteConfig(
								!ROUTE_OVERRIDE_RESERVED_KEYS.has(key),
								"`overrides.route." +
									axisName +
									"." +
									valueName +
									"." +
									key +
									"` cannot be overridden.",
							);
						}
					}
				}

				continue;
			}

			assertSolidBaseRouteConfig(
				configKeys.has(key),
				`\`overrides\` contains unknown config key or route axis \`${key}\`.`,
			);
		}

		validateRouteRule(selectors, axisMap, "overrides");
	}
}

export function normalizeSolidBaseRouteSelection(
	routes: SolidBaseRoutesConfig | undefined,
	selection: Partial<SolidBaseRouteSelection> = {},
) {
	const normalized: SolidBaseRouteSelection = {};

	for (const [axisName, axisConfig] of getSolidBaseRouteAxes(routes)) {
		const valueName = selection[axisName] ?? axisConfig.default;
		const value = axisConfig.values[valueName];

		if (!value || value.href) return undefined;

		normalized[axisName] = valueName;
	}

	return normalized;
}

export function matchesSolidBaseRouteRule(
	selection: SolidBaseRouteSelection,
	rule: SolidBaseRouteRule,
) {
	for (const [axisName, allowed] of Object.entries(rule)) {
		const current = selection[axisName];

		if (Array.isArray(allowed)) {
			if (!current || !allowed.includes(current)) return false;
			continue;
		}

		if (current !== allowed) return false;
	}

	return true;
}

export function isSolidBaseRouteIncluded(
	routes: SolidBaseRoutesConfig | undefined,
	selection: Partial<SolidBaseRouteSelection>,
) {
	const normalized = normalizeSolidBaseRouteSelection(routes, selection);
	if (!normalized) return false;
	if (!routes?.include) return true;

	return routes.include.some((rule) =>
		matchesSolidBaseRouteRule(normalized, rule),
	);
}

export function buildSolidBaseRoutePath(
	routes: SolidBaseRoutesConfig | undefined,
	selection: Partial<SolidBaseRouteSelection> = {},
) {
	const normalized = normalizeSolidBaseRouteSelection(routes, selection);
	if (!routes || !normalized || !isSolidBaseRouteIncluded(routes, normalized)) {
		return undefined;
	}

	const axes = getSolidBaseRouteAxisMap(routes);
	const pathSegments = getRouteTemplateSegments(routes.path).map((segment) => {
		if (segment.type === "static") return segment.value;

		const axis = axes.get(segment.name);
		const valueName = normalized[segment.name];
		if (!axis || !valueName) return "";

		const value = axis.values[valueName];
		return trimSlashes(value?.path ?? valueName);
	});

	return normalizeRoutePath(pathSegments.join("/"));
}

export function getSolidBaseRouteSelectionForPath(
	routes: SolidBaseRoutesConfig | undefined,
	path: string,
) {
	return getSolidBaseRouteMatchForPath(routes, path)?.selection;
}

export function getSolidBaseRouteMatchForPath(
	routes: SolidBaseRoutesConfig | undefined,
	path: string,
) {
	if (!routes) return undefined;

	const axes = getSolidBaseRouteAxisMap(routes);
	const pathSegments = trimSlashes(path).split("/").filter(Boolean);
	const selection: SolidBaseRouteSelection = {};
	let pathIndex = 0;

	for (const segment of getRouteTemplateSegments(routes.path)) {
		if (segment.type === "static") {
			if (pathSegments[pathIndex] !== segment.value) return undefined;
			pathIndex++;
			continue;
		}

		const axis = axes.get(segment.name);
		if (!axis) return undefined;

		const matched = matchRoutePathSegment(axis, pathSegments[pathIndex]);

		if (!matched) return undefined;

		const [valueName, value] = matched;
		selection[segment.name] = valueName;

		if (getRouteValuePath(valueName, value) !== "") pathIndex++;
	}

	if (!isSolidBaseRouteIncluded(routes, selection)) return undefined;

	return {
		selection,
		restPath: normalizeRoutePath(pathSegments.slice(pathIndex).join("/")),
	} satisfies SolidBaseRoutePathMatch;
}

export function getSolidBaseRoutePathWithRest(
	routes: SolidBaseRoutesConfig | undefined,
	selection: Partial<SolidBaseRouteSelection>,
	restPath: string,
) {
	const routePath = buildSolidBaseRoutePath(routes, selection);
	if (!routePath) return undefined;

	return normalizeRoutePath(`${routePath}/${restPath}`);
}

export function getSolidBaseRouteFallbackSelection(
	routes: SolidBaseRoutesConfig | undefined,
	current: Partial<SolidBaseRouteSelection> = {},
	next: Partial<SolidBaseRouteSelection> = {},
	options: { lockedAxes?: string[] } = {},
) {
	if (!routes) return undefined;

	const normalizedCurrent =
		normalizeSolidBaseRouteSelection(routes, current) ?? {};
	const axisMap = getSolidBaseRouteAxisMap(routes);
	const lockedSelection: Partial<SolidBaseRouteSelection> = {};

	for (const axisName of options.lockedAxes ?? []) {
		const valueName = normalizedCurrent[axisName];
		if (valueName) lockedSelection[axisName] = valueName;
	}

	const requiredSelection = {
		...lockedSelection,
		...next,
	};
	const required = normalizeSolidBaseRouteSelection(routes, {
		...normalizedCurrent,
		...requiredSelection,
	});
	if (!required) return undefined;

	let fallback: SolidBaseRouteSelection | undefined;
	let fallbackScore = -1;

	for (const selection of getSolidBaseRouteSelections(routes)) {
		if (
			Object.entries(requiredSelection).some(([axisName]) => {
				return selection[axisName] !== required[axisName];
			})
		) {
			continue;
		}

		let score = 0;
		for (const [axisName, axis] of axisMap) {
			if (selection[axisName] === normalizedCurrent[axisName]) {
				score += 100;
				continue;
			}

			if (selection[axisName] === axis.default) {
				score += 10;
			}
		}

		if (score > fallbackScore) {
			fallback = selection;
			fallbackScore = score;
		}
	}

	return fallback;
}

export function getSolidBaseRouteOptions(
	routes: SolidBaseRoutesConfig | undefined,
	axisName: string,
	current: Partial<SolidBaseRouteSelection> = {},
	routeOverride: SolidBaseRouteValueOverride = {},
): SolidBaseRouteOption[] {
	if (!routes) return [];

	const axis = getSolidBaseRouteAxisMap(routes).get(axisName);
	if (!axis) return [];

	const normalized = normalizeSolidBaseRouteSelection(routes, current) ?? {};
	const options: SolidBaseRouteOption[] = [];
	const axisOverride = routeOverride[axisName];

	for (const [valueName, value] of Object.entries(axis.values)) {
		const meta = {
			...value,
			...axisOverride?.[valueName],
		};

		if (value.href) {
			options.push({
				name: valueName,
				axis: axisName,
				href: value.href,
				isExternal: true,
				meta,
			});
			continue;
		}

		const selection = {
			...normalized,
			[axisName]: valueName,
		};

		if (!isSolidBaseRouteIncluded(routes, selection)) continue;

		options.push({
			name: valueName,
			axis: axisName,
			path: buildSolidBaseRoutePath(routes, selection),
			isExternal: false,
			selection,
			meta,
		});
	}

	return options;
}

export function getSolidBaseRouteFallbackOptions(
	routes: SolidBaseRoutesConfig | undefined,
	axisName: string,
	current: Partial<SolidBaseRouteSelection> = {},
	routeOverride: SolidBaseRouteValueOverride = {},
): SolidBaseRouteOption[] {
	if (!routes) return [];

	const axis = getSolidBaseRouteAxisMap(routes).get(axisName);
	if (!axis) return [];

	const axisNames = getRouteTemplateAxisNames(routes.path);
	const axisIndex = axisNames.indexOf(axisName);
	const lockedAxes = axisIndex > 0 ? axisNames.slice(0, axisIndex) : [];
	const options: SolidBaseRouteOption[] = [];
	const axisOverride = routeOverride[axisName];

	for (const [valueName, value] of Object.entries(axis.values)) {
		const meta = {
			...value,
			...axisOverride?.[valueName],
		};

		if (value.href) {
			options.push({
				name: valueName,
				axis: axisName,
				href: value.href,
				isExternal: true,
				meta,
			});
			continue;
		}

		const selection = getSolidBaseRouteFallbackSelection(
			routes,
			current,
			{
				[axisName]: valueName,
			},
			{ lockedAxes },
		);
		if (!selection) continue;

		options.push({
			name: valueName,
			axis: axisName,
			path: buildSolidBaseRoutePath(routes, selection),
			isExternal: false,
			selection,
			meta,
		});
	}

	return options;
}

function toRouteValuePatch(value: unknown): SolidBaseRouteValueOverrideConfig {
	if (typeof value === "string") return { label: value };
	if (isRecord(value)) {
		const patch: SolidBaseRouteValueOverrideConfig = {};

		for (const [key, item] of Object.entries(value)) {
			if (ROUTE_OVERRIDE_RESERVED_KEYS.has(key)) continue;
			patch[key] = item;
		}

		return patch;
	}
	return {};
}

function splitRouteOverride(override: RouteConfigValue, axisNames: string[]) {
	const selectors: SolidBaseRouteRule = {};
	const config: RouteConfigValue = {};
	const routeOverrides: SolidBaseRouteValueOverride = {};

	for (const [key, value] of Object.entries(override)) {
		if (axisNames.includes(key)) {
			if (typeof value === "string" || Array.isArray(value)) {
				selectors[key] = value as string | string[];
			}
			continue;
		}

		if (key === "routes" || key === "overrides") continue;

		if (key === ROUTE_OVERRIDE_KEY) {
			if (isRecord(value)) {
				for (const [axisName, values] of Object.entries(value)) {
					if (!isRecord(values)) continue;
					const axisOverrides = (routeOverrides[axisName] ??= {});
					for (const [valueName, patch] of Object.entries(values)) {
						axisOverrides[valueName] = toRouteValuePatch(patch);
					}
				}
			}
			continue;
		}

		config[key] = value;
	}

	return { selectors, config, routeOverrides };
}

function mergeRouteConfig<T extends RouteConfigValue>(
	base: T,
	override: RouteConfigValue,
): T {
	const result: RouteConfigValue = { ...base };

	for (const [key, value] of Object.entries(override)) {
		if (key === "themeConfig" && isRecord(result[key]) && isRecord(value)) {
			result[key] = {
				...result[key],
				...value,
			};
			continue;
		}

		result[key] = value;
	}

	return result as T;
}

export function resolveSolidBaseRouteValueOverrides(
	routes: SolidBaseRoutesConfig | undefined,
	overrides: RouteConfigValue[],
	selection: Partial<SolidBaseRouteSelection>,
): SolidBaseRouteValueOverride {
	const result: SolidBaseRouteValueOverride = {};
	if (!routes) return result;

	const normalized = normalizeSolidBaseRouteSelection(routes, selection);
	if (!normalized) return result;

	const axisNames = getSolidBaseRouteAxisNames(routes);

	for (const override of overrides) {
		const { selectors, routeOverrides } = splitRouteOverride(
			override,
			axisNames,
		);

		if (!matchesSolidBaseRouteRule(normalized, selectors)) continue;

		for (const [axisName, values] of Object.entries(routeOverrides)) {
			const axisResult = (result[axisName] ??= {});
			for (const [valueName, patch] of Object.entries(values)) {
				axisResult[valueName] = {
					...axisResult[valueName],
					...patch,
				};
			}
		}
	}

	return result;
}

export function resolveSolidBaseRouteConfig<T extends RouteConfigValue>(
	baseConfig: T & {
		overrides?: RouteConfigValue[];
		routes?: SolidBaseRoutesConfig;
	},
	selection: Partial<SolidBaseRouteSelection>,
): T {
	const { overrides: _overrides, ...base } = baseConfig;
	const routes = baseConfig.routes;
	if (!routes) return base as T;

	const normalized = normalizeSolidBaseRouteSelection(routes, selection);

	if (!normalized || !isSolidBaseRouteIncluded(routes, normalized)) {
		return base as T;
	}

	const axisNames = getSolidBaseRouteAxisNames(routes);
	let config = base as T;

	for (const override of baseConfig.overrides ?? []) {
		const { selectors, config: overrideConfig } = splitRouteOverride(
			override,
			axisNames,
		);

		if (!matchesSolidBaseRouteRule(normalized, selectors)) continue;

		config = mergeRouteConfig(config, overrideConfig);
	}

	return config;
}
