import { Tabs } from "@kobalte/core/tabs";
import {
	cookieStorage,
	makePersisted,
	messageSync,
} from "@solid-primitives/storage";
import type { ComponentProps } from "@solidjs/web";
import { isServer } from "@solidjs/web";
import {
	type Accessor,
	children,
	createSignal,
	For,
	omit,
	onCleanup,
	type ParentProps,
	Show,
	type Signal,
} from "solid-js";
import { fragmentAriaCurrent, useResolvedHref } from "../client/base-path.js";
import { usePreferredLanguage } from "../client/preferred-language.js";
import CopyPageLink from "../default-theme/components/CopyPageLink.jsx";
import { Preview, PreviewPanel, PreviewStage } from "./components/Preview.jsx";
import { useDefaultThemeComponents } from "./context.jsx";
import { useDefaultThemeFrontmatter } from "./frontmatter.js";
import styles from "./mdx-components.module.css";

export function h1(props: ComponentProps<"h1">) {
	const frontmatter = useDefaultThemeFrontmatter();
	const { Badges } = useDefaultThemeComponents();

	return (
		<div class={styles.actions}>
			<div class={styles.title}>
				<h1 class={styles.h1} {...props} />
				<Show when={frontmatter()?.copyButton !== false}>
					<div class={styles.pageAction}>
						<CopyPageLink />
					</div>
				</Show>
			</div>
			<Badges badges={frontmatter()?.badges} />
		</div>
	);
}

export function h2(props: ComponentProps<"h2">) {
	return <h2 class={styles.h2} {...props} />;
}

export function h3(props: ComponentProps<"h3">) {
	return <h3 class={styles.h3} {...props} />;
}

export function h4(props: ComponentProps<"h4">) {
	return <h4 class={styles.h4} {...props} />;
}

export function h5(props: ComponentProps<"h5">) {
	return <h5 class={styles.h5} {...props} />;
}

export function h6(props: ComponentProps<"h6">) {
	return <h6 class={styles.h6} {...props} />;
}

export function a(props: ComponentProps<"a"> & { "data-auto-heading"?: "" }) {
	const outbound = () => String(props.href ?? "").includes("//");
	const autoHeading = () => props["data-auto-heading"] === "";
	const href = useResolvedHref(() => props.href ?? "");

	return (
		<a
			target={outbound() ? "_blank" : undefined}
			rel={outbound() ? "noopener noreferrer" : undefined}
			class={autoHeading() ? styles["a-auto"] : styles.a}
			aria-current={fragmentAriaCurrent(props.href)}
			{...props}
			href={href()}
		/>
	);
}

export function code(props: ComponentProps<"code">) {
	return <code class={styles.code} {...props} />;
}

export function hr(props: ComponentProps<"hr">) {
	return <hr class={styles.hr} {...props} />;
}

export function table(props: ComponentProps<"table">) {
	const others = omit(props, "class");

	return (
		<div class={styles.table}>
			<table {...others} />
		</div>
	);
}

export function blockquote(props: ComponentProps<"blockquote">) {
	return <blockquote class={styles.blockquote} {...props} />;
}

export function p(props: ComponentProps<"p">) {
	return <p class={styles.p} {...props} />;
}

export function li(props: ComponentProps<"li">) {
	return <li class={styles.li} {...props} />;
}

export function ul(props: ComponentProps<"ul">) {
	return <ul class={styles.ul} {...props} />;
}

export function ol(props: ComponentProps<"ol">) {
	return <ol class={styles.ol} {...props} />;
}

export function DirectiveContainer(
	props: {
		type:
			| "info"
			| "note"
			| "tip"
			| "important"
			| "warning"
			| "danger"
			| "caution"
			| "details"
			| "tab-group"
			| "tab";
		title?: string;
		codeGroup?: string;
		tabNames?: string;
		withTsJsToggle?: string;
	} & ParentProps,
) {
	const resolved = children(() => props.children);

	if (props.type === "tab") {
		return <>{resolved()}</>;
	}

	if (props.type === "tab-group") {
		const tabNames = props.tabNames?.split("\0");
		const [preferredLanguage] = usePreferredLanguage();

		const tabs = (value?: Accessor<string>, onChange?: (s: string) => void) => (
			<Tabs
				value={value?.()}
				onChange={onChange}
				class={styles["tabs-container"]}
			>
				<Tabs.List class={styles["tabs-list"]}>
					{tabNames?.map((title) => {
						const jsTitle = title.replace(/\.tsx?$/, (ext) => {
							if (ext === ".tsx") {
								return ".jsx";
							}
							if (ext === ".ts") {
								return ".js";
							}
							return ext;
						});

						return (
							<Tabs.Trigger class={styles["tabs-trigger"]} value={title}>
								{preferredLanguage() === "ts" ? title : jsTitle}
							</Tabs.Trigger>
						);
					})}
					<Tabs.Indicator class={styles["tabs-indicator"]} />
					{props.withTsJsToggle === "true" && (
						<input
							type="checkbox"
							checked
							title="Toggle language"
							aria-label="Toggle TS/JS"
							class="sb-ts-js-toggle"
						/>
					)}
				</Tabs.List>

				<For each={tabNames}>
					{(title, i) => (
						<Tabs.Content
							value={title}
							forceMount={true}
							class={styles["tabs-content"]}
						>
							<div>{resolved.toArray()[i()]}</div>
						</Tabs.Content>
					)}
				</For>
			</Tabs>
		);

		if (!props.title) return tabs();

		// Sync named groups across groups and browser tabs; the channel is client-only.
		const channel = isServer ? undefined : new BroadcastChannel("tab-group");
		const [openTab, setOpenTab, , dispose] = makePersisted<
			string,
			Signal<string>
		>(createSignal(tabNames![0]!), {
			name: `tab-group:${props.title}`,
			sync: channel && messageSync(channel),
			storage: cookieStorage.withOptions({
				expires: new Date(Date.now() + 3e10),
			}),
			// Restore the saved tab after hydration so server and client markup match.
			hydrated: true,
		});
		onCleanup(() => {
			dispose();
			channel?.close();
		});

		// The key is shared across pages; fall back when this group lacks the saved tab.
		const selected = () =>
			tabNames!.includes(openTab()) ? openTab() : tabNames![0]!;

		return tabs(selected, setOpenTab);
	}

	if (props.type === "details") {
		return (
			<details
				class={styles["custom-container"]}
				data-custom-container="details"
			>
				<summary>{props.title ?? props.type}</summary>
				{resolved()}
			</details>
		);
	}

	return (
		<div class={styles["custom-container"]} data-custom-container={props.type}>
			<Show when={props.title !== " "}>
				<span>{props.title ?? props.type}</span>
			</Show>
			{resolved()}
		</div>
	);
}

export { Preview, PreviewPanel, PreviewStage };

export function Steps(props: ParentProps) {
	return <div class={styles.steps}>{props.children}</div>;
}

export function Step(props: ParentProps) {
	return <div class={styles.step}>{props.children}</div>;
}
